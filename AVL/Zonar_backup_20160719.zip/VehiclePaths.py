##City Of Columbia GIS
##Zane Kullman
##This script will prompt the user for username / pw, a date, a Zonar location,
##  and an output location. It will save a feature class with the points of
##  vehicles that fall into the Zonar location, and also create the lines
##  Examples of Zonar Locations include:
##      'Street - Grissum'
##      'Solid Waste - Grissum'
##      'Transit'
from Zonar import Zonar
import arcpy

zonar = Zonar() #will prompt for username / pw
zonarLoc = raw_input("Enter the case senstive Zonar Location or number:\n1.Street - Grissum\n2.Solid Waste - Grissum\n3.Parking - 5th & Walnut\n4.Sewer - WWTP\n5.Survey - City Hall\n6.Transit\n7.All\n\t>>")
date = raw_input("Enter the date to gather data from in YYYY-MM-DD format OR\n\t0 to enter a date range\n\t>>")
saveFile = raw_input("Enter the name of the output file\n\t>>")

##Turns a number key into the zonar location
if len(zonarLoc) == 1: #Entered a number
    zonarChoice = int(zonarLoc)
    if zonarChoice == 1:
        zonarLoc = "Street - Grissum"
    elif zonarChoice == 2:
        zonarLoc = "Solid Waste - Grissum"
    elif zonarChoice == 3:
        zonarLoc = "Parking - 5th & Walnut"
    elif zonarChoice == 4:
        zonarLoc = "Sewer - WWTP"
    elif zonarChoice == 5:
        zonarLoc = "Survey - City Hall"
    elif zonarChoice == 6:
        zonarLoc = "Transit"
    elif zonarChoice == 7:
        zonarLoc = "All"



##If Date Range was selected (0 during date selection)
if date == "0":
    StartDate = raw_input("Enter the start date in YYYY-MM-DD format\n\t>>")
    EndDate = raw_input("Enter the end date in YYYY-MM-DD format\n\t>>")
    data = zonar.getPathsManyDays(zonarLoc, StartDate, EndDate)
else:
    ##Gets the XML data from Zonar
    data = zonar.getPaths(zonarLoc, date)
print "Data Downloaded"

##Creates feature for points
arcpy.env.overwriteOutput = True
print "env set"
arcpy.env.workspace = "J:\\AVL\\Zonar\\Zonar.gdb"
print "workspace set"
WGS84 = arcpy.SpatialReference(4326)
print "Spatial Ref Set"
arcpy.CreateFeatureclass_management("J:\\AVL\\Zonar\\Zonar.gdb", saveFile, "POINT", "J:\AVL\Zonar\Zonar.gdb\PathPointTemplate", spatial_reference = WGS84)
print "Feature Class Created"

##Create Insert Cursor
cursor = arcpy.da.InsertCursor(saveFile,['Fleet_ID', 'SHAPE@XY', 'Date_Time', 'Speed'])

##Formats XML data into variables, saves them into arc feature class created above
for asset in data:
    #fleetID = zonar.lookupAssetByID(asset.attrib['id'])
    fleetID = asset.attrib['id']
    for event in asset:
        point = arcpy.PointGeometry(arcpy.Point(event.attrib['long'],event.attrib['lat']))
        timestamp = event.attrib['time']
        speed = event.attrib['speed']

        #into arc
        cursor.insertRow((fleetID, point, timestamp, speed))
        
del cursor
print "Created Points"
arcpy.PointsToLine_management(saveFile, saveFile+"_Lines","Fleet_ID")
print "Created Lines"
a = raw_input("Press Enter to close")
exit()
