##City Of Coumbia GIS
##Zane Kullman
##Work in Progress creating a Zonar Python Library

import requests
import time, datetime
import xml.etree.ElementTree as ET
import getpass

class Zonar:
    def __init__(self, url="https://col2225.zonarsystems.net/interface.php"):
        """Creates a Zonar Object"""
        self.zonarUrl = url
        self.__authenticate()

    def __authenticate(self):
        """Login - Called when zonar object is created"""
        username = raw_input("Enter Zonar Username: ")
        password = getpass.getpass("Enter your Zonar Password: ")
        self.__auth = {'username':username, 'password':password}
        
    def getLocation(self, Fleet_ID, Type='Standard'):
        """Gets the location of an asset refrenced by Fleet ID (License plate) Returns Tuple"""
        data = self.__querySigle(Fleet_ID, Type)
        xy = (data[0].text, data[1].text)
        return xy

    def getSingleDict(self, Fleet_ID, Type = 'Standard'):
        """Gets the full data output of an asset refrenced by Fleet ID (License Plate)
            Returns Dictionary"""
        data = self.querySingle(Fleet_ID, Type)
        outData = {data[0].tag: float(data[0].text),
                   data[1].tag: float(data[1].text),
                   data[2].tag: float(data[2].text),
                   data[3].tag: str(data[3].text),
                   data[4].tag: float(data[4].text),
                   data[5].tag: str(data[5].text),
                   data[6].tag: float(data[6].text)}
        return outData

    def queryManyByLocation(self, Location, Type = 'Standard', Power = ''):
        """Use this method instead of itterating querySingle to prevent rate limiting
        If power is set to 'On' this will only return assets powered on
        Returns an Element Tree object of the results. Returns XML"""
        payload = self.__auth
        payload['action'] = 'showposition'
        payload['operation'] = 'current'
        payload['format'] = 'xml'
        payload['logvers'] = '3.3'    
        payload['type'] = Type
        payload['locname'] = Location

        if Power == 'on':
            payload['power'] = 'on'

        r = requests.post(self.zonarUrl, payload)
        data = ET.fromstring(r.text)
        return  data
    
    def queryAll(self):
        """Returns all assets in an element tree (XML)"""
        payload = self.__auth
        payload['action'] = 'showposition'
        payload['operation'] = 'current'
        payload['format'] = 'xml'
        payload['logvers'] = '3.3'
        r = requests.post(self.zonarUrl, payload)
        data = ET.fromstring(r.text)
        return  data
        
    def querySingle(self, Fleet_ID, Type = 'Standard'):
        """Used to Query a single asset, returns as a XML Object"""
        payload = self.__auth
        payload['action'] = 'showposition'
        payload['operation'] = 'current'
        payload['format'] = 'xml'
        payload['logvers'] = '3.3'    
        payload['reqtype'] = 'fleet'
        payload['type'] = Type
        payload['target'] = str(Fleet_ID)
        r = requests.post(self.zonarUrl, payload)
        data = ET.fromstring(r.text)[0]
        return data

    def getEpochRange(self, date):
        """Given a date, returns a tuple from 12AM to 11:59PM of that day
        Date must be in YYYY-MM-DD format, including the hyphen"""
        startDateTime = date + " 00:00:00" #Start at 12AM
        endDateTime = date + " 23:59:59" #End at 11:59:59PM
        print startDateTime, endDateTime
        startEpoch = int(time.mktime(time.strptime(startDateTime, '%Y-%m-%d %H:%M:%S'))) - time.timezone
        endEpoch = int(time.mktime(time.strptime(endDateTime, '%Y-%m-%d %H:%M:%S'))) - time.timezone
        print startEpoch, endEpoch
        return (startEpoch, endEpoch)

    def getEpochTime(self, date, AMorPM):
        if AMorPM == "AM":
            DateTime = date + " 00:00:00"
        else:
            DateTime = date + " 23:59:59"
        print DateTime
        epoch = int(time.mktime(time.strptime(DateTime, '%Y-%m-%d %H:%M:%S'))) - time.timezone
        print epoch
        return epoch
        

    def getPaths(self, Location, Date, Type="Standard"):
        """Use this method to get a XML Object for all vehicles on a day
        Date must be formatted YYYY-MM-DD
        Returns XML, and the UID for each vehicle is it's DIB, not Fleet ID.
        See lookupByID to covert"""

        """Return data is structured as a tree, a list of Assets, each with a list of events, events have xy"""
        payload = self.__auth
        day = self.getEpochRange(Date)
        payload['starttime'] = day[0]
        payload['endtime'] = day[1]

        if Location != "All": #If it is "" then it will return all
            payload['location'] = Location
        else:
            print "Gathering all data will take a while"
        
        payload['action'] = 'showposition'
        payload['operation'] = 'path'
        payload['format'] = 'xml'
        payload['logvers'] = '3.2'
        payload['version'] = '2'

        req = requests.post(self.zonarUrl, payload)
        data = ET.fromstring(req.text)
        return data

    def getPathsManyDays(self, Location, StartDate, EndDate, Type="Standard"):
        """Use this method to get a XML Object for vehicles over a range of days
        Date must be formatted YYYY-MM-DD
        Returns XML, and the UID for each vehicle is it's DIB, not Fleet ID.
        See lookupByID to covert
        Use 'Location = All' to get every vehicle"""

        """Return data is structured as a tree, a list of Assets, each with a list of events, events have xy"""
        payload = self.__auth
        payload['starttime'] = self.getEpochTime(StartDate, "AM")
        payload['endtime'] = self.getEpochTime(EndDate, "PM")

        if Location != "All": #If it is "" then it will return all
            payload['location'] = Location
        else:
            print "Gathering all data will take a while"
        
        payload['action'] = 'showposition'
        payload['operation'] = 'path'
        payload['format'] = 'xml'
        payload['logvers'] = '3.2'
        payload['version'] = '2'

        req = requests.post(self.zonarUrl, payload)
        data = ET.fromstring(req.text)
        return data

    def getAssetsFromLocation(self, Location):
        """This Method is not tested, and requires zonar asset control
        This should return an XML of all the assets at a location"""
        payload = self.__auth
        payload['action'] = 'showopen'
        payload['operation'] = 'showassets'
        payload['format'] = 'xml'
        payload['location'] = Location
        r = requests.post(self.zonarUrl, payload)
        data = ET.fromstring(r.text)
        return data

    def lookupAssetByID(self, assetID):
        """This method returns a fleet ID as string when given an asset ID
        Untested, no rights yet"""
        payload = self.__auth
        payload['action'] = 'showopen'
        payload['operation'] = 'showassets'
        payload['format'] = 'xml'
        payload['target'] = str(assetID)
        payload['reqtype'] = 'dbid'
        req = requests.post(self.zonarUrl, payload)
        data = ET.fromstring(r.text)
        return data[0].attrib['name']

    def createKMLPathLink(self, assetID, StartDate, EndDate, Type="Standard"):
        """This method returns a KML link for ArcOnline. Requires a fleet ID
        and date IDs as 'YYYY-MM-DD """
        payload = self.__auth
        payload['starttime'] = self.getEpochTime(StartDate, "AM")
        payload['endtime'] = self.getEpochTime(EndDate, "PM")
        payload['target'] = str(assetID)
        payload['format'] = 'kml'
        payload['logvers'] = '3.2'
        payload['version'] = '2'
        payload['reqtype'] = 'fleet'
        payload['action'] = 'showposition'
        payload['operation'] = 'path'
        payload['type'] = Type
        outUrl = self.zonarUrl + "?"
        for key in payload.keys():
            outUrl = outUrl + "{}={}&".format(key, payload[key])
        outUrl = outUrl[0:len(outUrl)-1] #Delete the last & sign
        return outUrl

    def createKMLLocationLink(self, assetID, Type="Standard"):
        payload = self.__auth
        payload['action'] = 'showposition'
        payload['operation'] = 'current'
        payload['version'] = '2'
        payload['logvers'] = '3'
        payload['format'] = 'kml'
        payload['target'] = str(assetID)
        payload['reqtype'] = "fleet"
        payload['type'] = Type

        outUrl = self.zonarUrl + "?"
        for key in payload.keys():
            outUrl = outUrl + "{}={}&".format(key, payload[key])
        outUrl = outUrl[0:len(outUrl)-1] #Delete the last & sign
        return outUrl
