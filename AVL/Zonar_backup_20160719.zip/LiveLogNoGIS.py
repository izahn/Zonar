##City Of Coumbia GIS
##Created By Zane Kullman
##Uses Zonar Library to place data into a text file, can be turned into a csv from there
##Also creates a log of how often the program pulls

from Zonar import Zonar
import sched
import time

def update(scheduler, zonar):
    start_time = time.time()
    s.enter(1,1,update,(scheduler, zonar))
    f = open("LiveLogLog09.txt",'a')
    g = open("RowDataMay09.txt", 'a')
    data = zonar.queryManyByLocation('Street - Grissum', Power='on') #Location Filters
    offlineStack = []
    for vehicle in data:

        if vehicle.attrib['fleet'] == '1657' or vehicle.attrib['fleet'] == '1658' or vehicle.attrib['fleet'] == '1697': ##Fleet Filter, append 'or True' to have it work all vehicles in that zone
            
            xy = (float(vehicle[0].text), float(vehicle[1].text))
            row = [vehicle.attrib['fleet'], xy, vehicle[3].text, vehicle[2].text, vehicle[4].text, vehicle[5].text]
            textRow = [vehicle.attrib['fleet'], vehicle[3].text, vehicle[2].text, vehicle[4].text, vehicle[5].text, vehicle[0].text, vehicle[1].text]
            g.write(",".join(textRow) + "\n")
            print textRow
            try:
                f.write("Point {} Created, -1\n".format(vehicle.attrib['fleet']))
                print (row)
                if len(offlineStack) > 0: ##If there is anything in the stack
                    for i, item in enumerate(offlineStack):
                       print 'try to paste stack'
                       del offlineStack[i]
            except:
                offlineStack.append(row)
    f.write("{} Seconds\t{} stack\n".format((time.time() - start_time), len(offlineStack)))
    print("--- {} seconds --- {} stack ---".format((time.time() - start_time), len(offlineStack)))
    f.close()
    g.close()

zonar = Zonar()
offlineStack = []

cursor = "hi"
s = sched.scheduler(time.time, time.sleep)
s.enter(2,1,update, (s,zonar))
s.run()
