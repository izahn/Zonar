##City Of Coumbia GIS
##Zane Kullman
##Uses Zonar Library to place points into GDB

import arcpy
from Zonar import Zonar
import sched

import time

def update(scheduler, zonar, cursor, offlineStack):
    """Cursor must be an insert cursor"""
    start_time = time.time()
    s.enter(1,1,update,(scheduler, zonar, cursor, offlineStack))
    f = open("LiveLogLog2.txt",'a')
    g = open("RowDataApril13.txt", 'a')
    data = zonar.queryManyByLocation('Street - Grissum', Power='on') #Location Filters
    for vehicle in data:

        if vehicle.attrib['fleet'] == '1657' or vehicle.attrib['fleet'] == '1658' or vehicle.attrib['fleet'] == '1697': ##Fleet Filter, append 'or True' to have it work all vehicles in that zone
            
            xy = (float(vehicle[0].text), float(vehicle[1].text))
            row = [vehicle.attrib['fleet'], xy, vehicle[3].text, vehicle[2].text, vehicle[4].text, vehicle[5].text]
            textRow = [vehicle.attrib['fleet'], vehicle[3].text, vehicle[2].text, vehicle[4].text, vehicle[5].text, vehicle[0].text, vehicle[1].text]
            g.write(",".join(textRow) + "\n")
            try:
                cursor.insertRow(row)
                f.write("Point {} Created, -1\n".format(vehicle.attrib['fleet']))
                print (row)
                if len(offlineStack) > 0: ##If there is anything in the stack
                    for i, item in enumerate(offlineStack):
                       cursor.insertRow(item)
                       print 'try to paste stack'
                       del offlineStack[i]
            except:
                offlineStack.append(row)
    f.write("{} Seconds\t{} stack\n".format((time.time() - start_time), len(offlineStack)))
    print("--- {} seconds --- {} stack ---".format((time.time() - start_time), len(offlineStack)))
    f.close()
    g.close()
    
def setupCursor():
    fc = "TruckTracks\\April13" #This is where data will be saved
    fields = ["Fleet_ID", "SHAPE@XY", "Date_Time", "Heading", "Speed", "Power"] #Fields in order
    return arcpy.da.InsertCursor(fc, fields)

arcpy.env.workspace = "J:\\AVL\\Zonar\\Zonar.gdb" ###CHANGE THIS LINE
zonar = Zonar()
cursor = setupCursor()
offlineStack = []

s = sched.scheduler(time.time, time.sleep)
s.enter(2,1,update, (s,zonar,cursor,offlineStack))
s.run()
